const path = require("path")
const fs = require("fs")

class FileRepository {
    constructor(data) {
        this.data = data || [];
        this.isDataLoaded = false;
        this.allowedValues = {}
        this.loadData()
    }

    async loadData() {
        this.isDataLoaded = false;
        try {
            const data = await fs.readFileSync(process.env.DATA_PATH, "utf-8");
            this.data = JSON.parse(data);
            this.setAllowedValues();
        } catch (err) {
            console.log("File Reading Error", err);
        }
        this.isDataLoaded = true;
    }

    setAllowedValues() {
        const allowdvalueMatches = ["Auth", "HTTPS", "Cors", "Category"];
        if (this.isDataLoaded) {
            this.data.forEach(element => {
                allowdvalueMatches.forEach(item => {
                    const value = element?.[item] || null;
                    if (value) {
                        if (this.allowedValues in item) {
                            this.allowedValues[item].add(value)
                        } else {
                            this.allowedValues[item] = new Set(value)
                        }
                    }
                })
            });
        }
    }

    matchPattern(key, value,  search){
        if( (key === "API" || key === "Description") && typeof(value) === "string" ){
           return (value.toLocaleLowerCase().search(new RegExp(new String(search), "ig")) || -1) >= 0
        }else{
            return value == search;
        }
    }

    findRecord(query){
        if(Object.keys(query).length == 0){
            return this.data;
        }
        return this.data.filter(item=>{
            for(const [key, value] of Object.entries(query)){
                if(this.matchPattern(key, item?.[key], value) === false){
                    return false
                }
            }
            return true
        }) 
    }

}

module.exports = {FileRepository};