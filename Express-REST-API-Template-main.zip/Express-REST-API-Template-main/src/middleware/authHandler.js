const { JWTTokenVerification } = require('../proxy/utils');

const WHITELISTED_ENDPOINT = ['/login'];

// eslint-disable-next-line no-unused-vars
const authHandler = (req, res, next) => {
  console.log(req.path, WHITELISTED_ENDPOINT.includes(req.path));
  if (WHITELISTED_ENDPOINT.includes(req.path)) {
    next();
  } else {
    const { authorization } = req.headers;
    const jwtToken = authorization.split(' ')[1]; // Remove Bearer from string
    if (jwtToken === 'null' || !jwtToken)
      return res.status(401).send({ message: 'Unauthorized request' });
    try {
      JWTTokenVerification(jwtToken);
      next();
    } catch (err) {
      let message = 'Unauthorized request';
      if (err.name === 'TokenExpiredError') {
        message = 'Token Expired.';
      } else if (err.name === 'JsonWebTokenError') {
        message = 'Invalid Token';
      }
      console.log(err.name);
      res.status(401).send({ message });
    }
  }
};

module.exports = authHandler;
