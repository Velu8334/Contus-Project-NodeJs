const express = require('express');
const { SearchService } = require('../services/filter.service');
const { createPageLink } = require('../proxy/utils');
const { SearchFilterCache } = require('../proxy/cacheRecordHandler');

const router = express.Router();
const cacheRecordHandler = new SearchFilterCache();
const service = new SearchService(10);
const MAX_PAGE_LIMIT = 50;
router.get('/', (req, res) => {
  try {
    const params = new URLSearchParams(req.query);
    const paramObject = Object.fromEntries(params.entries());
    const page = parseInt(req?.query?.page || 1);
    const limit = parseInt(req?.query?.limit || 50);
    paramObject['page'] = page;
    paramObject['limit'] = limit;
    if (limit > MAX_PAGE_LIMIT) {
      return res.status(400).send({
        success: false,
        message: `Maximum page limit is ${MAX_PAGE_LIMIT}`,
      });
    }
    const getCacherecords = cacheRecordHandler.getCacheData(paramObject);
    if (getCacherecords) {
      return res.status(200).send(getCacherecords);
    }
    let response = service.getAllData(paramObject);
    if (response.count > 0) {
      cacheRecordHandler.setCacheData(paramObject, response);
    }
    res.status(200).send(response);
  } catch (err) {
    res.status(500).send({
      message: 'Server Error.',
      reason: err.message,
    });
  }
});

module.exports = router;
