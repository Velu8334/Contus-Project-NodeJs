const express = require('express');
const { generateJWTToken } = require('../proxy/utils');

const router = express.Router();
router.post('/', (req, res) => {
  try {
    const body = req.body || {};
    if (body.username === 'username' && body.password === 'password') {
      res.status(200).send({
        type: 'Bearer',
        expire: parseInt(process?.env?.JWT_EXPIRE || '80') * 1000,
        token: generateJWTToken({ name: body.username }),
      });
    } else {
      res
        .status(401)
        .send({ success: false, message: 'Please Enter Valid Credentials' });
    }
  } catch (err) {
    res.status(500).send({
      message: 'Validation Failed....',
      reason: err.message,
    });
  }
});

module.exports = router;
