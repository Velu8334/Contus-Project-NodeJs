const { FileRepository } = require("../repository/file.repo");

class SearchService {
    constructor(limit) {
        this.limit = limit || 10;
        this.repo = new FileRepository();
        this.validParms =  ['API', 'Description', 'Auth', 'HTTPS', 'Cors', 'Link', 'Category'];
    }
    
    generateValidParams(query){
        const result = {}
        this.validParms.forEach(item=>{
            if(query?.[item]){
                result[item] = query[item]
            }
        })
        return result;
    }


    getAllData(query) {
        const page = parseInt(query?.page || 1)
        const limit = parseInt(query?.limit || 10) || this.limit
        const start = (page - 1) * limit;
        const data = this.repo.findRecord(this.generateValidParams(query));
        const total = data.length;
        const result = data.slice(start, start + limit)
        return {
            page,
            total,
            data:result
        }

    }

}

module.exports = { SearchService};