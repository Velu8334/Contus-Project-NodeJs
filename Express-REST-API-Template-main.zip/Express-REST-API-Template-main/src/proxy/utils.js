const jwt = require('jsonwebtoken');

const generateJWTToken = (data) => {
  return jwt.sign(data, process.env.JWT_TOKEN, {
    expiresIn: parseInt(process?.env?.JWT_EXPIRE || '80'),
  });
};
const JWTTokenVerification = (token) => {
  return jwt.verify(token, process.env.JWT_TOKEN);
};

module.exports = { generateJWTToken, JWTTokenVerification };
