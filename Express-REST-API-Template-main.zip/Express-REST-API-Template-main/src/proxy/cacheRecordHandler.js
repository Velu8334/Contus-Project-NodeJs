const NodeCache = require('node-cache');

class SearchFilterCache {
  constructor() {
    this.cacheRecords = new NodeCache({ stdTTL: 300, checkperiod: 60 });
    this.flitters = [
      'page',
      'limit',
      'API',
      'Description',
      'Auth',
      'HTTPS',
      'Cors',
      'Link',
      'Category',
    ];
  }
  prepareQueryKeys(query) {
    let key = Object.keys(query).length === 0 ? 'full' : '';
    this.flitters.forEach((element) => {
      if (query?.[element] || null !== null) {
        key += `${element}:${query[element]};`;
      }
    });
    return key;
  }
  getCacheData(query) {
    const key = this.prepareQueryKeys(query);
    return this.cacheRecords.get(key) || null;
  }
  setCacheData(query, data) {
    const key = this.prepareQueryKeys(query);
    return this.cacheRecords.set(key, data);
  }
}

module.exports = { SearchFilterCache };
