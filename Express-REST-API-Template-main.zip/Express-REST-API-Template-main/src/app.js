const express = require('express');
const createError = require('http-errors');
const cookieParser = require('cookie-parser');
const logger = require('morgan');
const helmet = require('helmet');
require('dotenv').config();
const indexRouter = require('./routes/index');
const loginRouter = require('./routes/loginPage');

const errorHandler = require('./middleware/errorHandler');
const authHandler = require('./middleware/authHandler');

const app = express();

app.use(helmet()); // https://expressjs.com/en/advanced/best-practice-security.html#use-helmet
app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());

app.use(authHandler);
app.use('/login', loginRouter);
app.use('/', indexRouter);

// catch 404 and forward to error handler
app.use((req, res, next) => {
  next(createError.NotFound());
});

// pass any unhandled errors to the error handler
app.use(errorHandler);

if (process.env.NODE_ENV === 'development') {
  const PORT = 4000;
  app.listen(PORT, () => {
    console.log(`Server running on port : ${PORT}`);
  });
}
module.exports = app;
