# Contributing

1. [Fork](https://docs.github.com/en/get-started/quickstart/fork-a-repo) this repository
2. Clone your fork: `git clone git@github.com:{your-username}/Express-REST-API-Template.git`
3. Create a branch for your contribution: `git checkout -b {branch-name-for-contribution}`
4. Push your changes back to GitHub: `git push --set-upstream origin {branch-name-for-contribution}`
5. Open a [Pull Request](https://docs.github.com/en/github/collaborating-with-pull-requests/proposing-changes-to-your-work-with-pull-requests/creating-a-pull-request-from-a-fork) with your changes
